<?php

return [

    'name'              => 'ElegantTemplate',
    'description'       => 'This is my awesome module',

];