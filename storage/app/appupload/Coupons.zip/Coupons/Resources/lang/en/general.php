<?php

return [

    'name'              => 'Coupons',
    'description'       => 'This is my awesome module',

];