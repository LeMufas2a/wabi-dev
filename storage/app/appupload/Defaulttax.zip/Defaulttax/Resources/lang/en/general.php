<?php

return [

    'name'              => 'Defaulttax',
    'description'       => 'This is my awesome module',

];