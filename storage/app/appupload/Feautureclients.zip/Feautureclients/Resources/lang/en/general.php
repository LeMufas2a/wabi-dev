<?php

return [

    'name'              => 'Feautureclients',
    'description'       => 'This is my awesome module',

];