<?php

return [

    'name'              => 'PaddleSubscribe',
    'description'       => 'This is my awesome module',

];