<?php

return [

    'name'              => 'Domain',
    'description'       => 'This is my awesome module',

];